import java.sql.*;

import javax.swing.JOptionPane;


public class mysql_connection {
	
	public static Connection mysql_Connector() {
		try{  
			Class.forName("com.mysql.cj.jdbc.Driver");

			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/lms","root","123456");
			
			return conn;
			
		}catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
			return null;
		}

	}

}
