import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.SwingConstants;

//import com.mysql.jdbc.Connection;

import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
import java.awt.event.ActionEvent;

public class Login {

	public JFrame frame_login;
	private JTextField text_login_user;
	private JPasswordField password_login;
	private int customer = 0;
	private int admin = 0;
	public int current_customer_id = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login(0);
					window.frame_login.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	Connection connection = null;

	/**
	 * Create the application.
	 */
	public Login(int cid_now) {		
		initialize();
		
		connection = mysql_connection.mysql_Connector();
		
		current_customer_id = cid_now;
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame_login = new JFrame();
		frame_login.setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/img/login_frame_icon.png")));
		frame_login.setTitle("LOGIN");
		frame_login.setResizable(false);
		frame_login.setBounds(100, 100, 1000, 600);
		frame_login.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame_login.getContentPane().setLayout(null);
		
		JLabel label_password_icon = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/img/login_password_icon.png")).getImage();
		label_password_icon.setIcon(new ImageIcon(img));
		label_password_icon.setBounds(96, 216, 74, 80);
		frame_login.getContentPane().add(label_password_icon);
		
		JLabel label_user_icon = new JLabel("");
		Image img1 = new ImageIcon(this.getClass().getResource("/img/login_user_icon.png")).getImage();
		label_user_icon.setIcon(new ImageIcon(img1));
		label_user_icon.setBounds(96, 149, 70, 58);
		frame_login.getContentPane().add(label_user_icon);
		
		text_login_user = new JTextField();
		text_login_user.setToolTipText("USER");
		text_login_user.setFont(new Font("Tahoma", Font.PLAIN, 20));
		text_login_user.setBounds(213, 161, 194, 35);
		frame_login.getContentPane().add(text_login_user);
		text_login_user.setColumns(10);
		
		password_login = new JPasswordField();
		password_login.setFont(new Font("Tahoma", Font.PLAIN, 15));
		password_login.setEchoChar('*');
		password_login.setToolTipText("PASSWORD");
		password_login.setBounds(213, 238, 194, 35);
		frame_login.getContentPane().add(password_login);
		
		JRadioButton radio_login_who_admin = new JRadioButton("Admin");
		radio_login_who_admin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				customer = 0;
				admin = 1;
				
			}
		});
		radio_login_who_admin.setFont(new Font("Tahoma", Font.PLAIN, 15));
		radio_login_who_admin.setToolTipText("Admin");
		radio_login_who_admin.setBounds(329, 297, 80, 21);
		frame_login.getContentPane().add(radio_login_who_admin);
		
		JRadioButton radio_login_who_customer = new JRadioButton("Customer");
		radio_login_who_customer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				admin = 0;
				customer = 1;
				
			}
		});
		radio_login_who_customer.setFont(new Font("Tahoma", Font.PLAIN, 15));
		radio_login_who_customer.setToolTipText("Customer");
		radio_login_who_customer.setBounds(213, 297, 97, 21);
		frame_login.getContentPane().add(radio_login_who_customer);
		
		ButtonGroup test = new ButtonGroup();
		test.add(radio_login_who_customer);
		test.add(radio_login_who_admin);
		
		JButton button_login_get_drunk = new JButton("GET DRUNK");
		button_login_get_drunk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					
					if (text_login_user.getText() == null || text_login_user.getText().trim().isEmpty() || password_login.getText() == null || password_login.getText().trim().isEmpty()) {
						JOptionPane.showMessageDialog(null, "All The Fields Should Be Filled","Alert",JOptionPane.WARNING_MESSAGE);
					}	
					
					// customer
					if (customer == 1) {
						String query = "select * from lms.customer where cname=? and pass=?";
						PreparedStatement pst = connection.prepareStatement(query); 
						pst.setString(1, text_login_user.getText());
						pst.setString(2, password_login.getText());
						
						ResultSet rs = pst.executeQuery();
						
						int count = 0;
						
						while (rs.next()) {
							count++;
							current_customer_id = rs.getInt("cid");
							System.out.println("cid "+current_customer_id);
						}
						
						if (count == 1) {
							JOptionPane.showMessageDialog(null, "Correct Customer");
							
							frame_login.dispose();
							
							customer_view cust_view = new customer_view(current_customer_id);
							cust_view.setVisible(true);
							
						} else {
							JOptionPane.showMessageDialog(null, "Not Correct");
						}
					
						rs.close();
						pst.close();
					}
					
					// admin
					if (admin == 1) {
						String query = "select exists(select * from admins where adminid=? and pass=?)";
						PreparedStatement pst = connection.prepareStatement(query); 
						pst.setString(1, text_login_user.getText());
						pst.setString(2, password_login.getText());
						
						ResultSet rs = pst.executeQuery();
						
						if (rs.next() == true) {
							JOptionPane.showMessageDialog(null, "Correct Admin");
							
							frame_login.dispose();
							
							admin_view ad_view = new admin_view();
							ad_view.setVisible(true);
							
						} else {
							JOptionPane.showMessageDialog(null, "Not Correct");
						}
					
						rs.close();
						pst.close();
					}
					
				} catch (SQLException e1) {
					e1.printStackTrace();
				} 
			}
		});
		button_login_get_drunk.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 13));
		button_login_get_drunk.setHorizontalAlignment(SwingConstants.LEFT);
		Image img2 = new ImageIcon(this.getClass().getResource("/img/get_drunk_icon.png")).getImage();
		button_login_get_drunk.setIcon(new ImageIcon(img2));
		button_login_get_drunk.setBounds(213, 356, 147, 35);
		frame_login.getContentPane().add(button_login_get_drunk);
		
		JLabel label_login_main_title = new JLabel("LIQUOR MANAGEMENT SYSTEM");
		label_login_main_title.setForeground(Color.ORANGE);
		label_login_main_title.setFont(new Font("Tahoma", Font.BOLD, 35));
		label_login_main_title.setBounds(10, 10, 563, 75);
		frame_login.getContentPane().add(label_login_main_title);
		
		JLabel label_login_background = new JLabel("");
		label_login_background.setFont(new Font("Tahoma", Font.PLAIN, 25));
		Image img3 = new ImageIcon(this.getClass().getResource("/img/login_background_1000x600.jpg")).getImage();
		label_login_background.setIcon(new ImageIcon(img3));
		label_login_background.setBounds(0, 0, 996, 572);
		frame_login.getContentPane().add(label_login_background);
	}
}
