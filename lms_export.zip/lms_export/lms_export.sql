create database lms;

use lms;

-- create part
create table lms.customer(
	cid int not null auto_increment,
    cname varchar(30) NOT NULL,
    pass varchar(6) NOT NULL,
    dob date,
    phone bigint,
    address varchar(50),
    primary key (cid)
);
alter table lms.customer auto_increment = 1000;

create table lms.payment(
	pyid int NOT NULL auto_increment,
    pystatus varchar(5),
    method varchar(20),
    primary key (pyid)
);
alter table lms.payment auto_increment = 10000;

create table lms.orders(
	oid int not null auto_increment,
    pyid int,
    cid int,
    odate date,
    ostatus varchar(20),
    dl_date date,
    total int,
    primary key (oid),
    constraint fkpayment foreign key (pyid)
    references lms.payment(pyid)
    on update cascade
    on delete restrict,
    constraint fkcustomer foreign key (cid)
    references lms.customer(cid)
    on update cascade
    on delete restrict
);
alter table lms.orders auto_increment = 5000;

create table lms.category(
	catid int not null,
    catname varchar(40) unique,
    primary key (catid)
);

create table lms.chart(
	bid int not null,
    bname varchar(40) unique,
    world_con int,
    primary key (bid)
);

create table lms.product(
	pid int not null,
    bid int,
    catid int,
    pname varchar(40),
    unitprice int,
    instock char,
    netqt int,
    primary key (pid),
    constraint fkcategory foreign key (catid)
    references lms.category(catid)
    on update cascade
    on delete set null,
    constraint fkchart foreign key (bid)
    references lms.chart(bid)
    on update cascade
    on delete set null
);
ALTER TABLE lms.product
ADD alc_per int;

create table lms.includes(
	pid int,
    oid int,
--  constraint fkproduct foreign key (pid)	-- not applied here bcoz of some defficulty in gui part
--  references lms.product(pid)
--  on update cascade
--  on delete cascade,
    constraint fkorders foreign key (oid)
    references lms.orders(oid)
    on update cascade
    on delete cascade
);
ALTER TABLE lms.includes
ADD no_units int;

create table lms.admins(
	adminid varchar(6) not null unique,
    pass varchar(6) not null,
    primary key (adminid)
);

create table lms.customer_archive(
	cid int,
    cname varchar(30),
    pass varchar(6),
    dob date,
    phone bigint,
    address varchar(50)
);


-- insert part
insert into admins
values ('sharat', '123456'),
	   ('harshi', '234567'),
       ('danush', '345678');

INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('301', 'Beer');
INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('302', 'Whisky');
INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('303', 'Blended Scotch Whisky');
INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('304', 'Tennesse Whisky');
INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('305', 'Rum');
INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('306', 'Vodka');
INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('307', 'Wine');
INSERT INTO `lms`.`category` (`catid`, `catname`) VALUES ('308', 'Tequila');

INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('201', 'Carlsberg Group', '11');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('202', 'Anheuser-Busch', '8');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('203', 'United Breweries', '9');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('204', 'B9 Beverages', '10');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('205', 'Irish Distillers', '6');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('206', 'Pernod Ricard', '6');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('207', 'Diageo', '10');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('208', 'Brow Forman', '4');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('209', 'Demerara Distillere', '4');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('210', 'Aiyush Mohan', '8');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('211', 'St. Lucia Distillere', '5');
INSERT INTO `lms`.`chart` (`bid`, `bname`, `world_con`) VALUES ('212', 'Bacardi', '9');

INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('101', 'Tuborg Strong', '150', 'y', '650', '8');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('102', 'Budweiser Magnum', '200', 'y', '650', '10');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('103', 'Kingfisher Ultra Max', '180', 'y', '650', '12');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('104', 'Bira Boom', '145', 'y', '650', '10');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('105', 'Jameson', '3000', 'y', '750', '38');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('106', 'Ballantinee', '5650', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('107', 'Black Dog Reserve', '7800', 'y', '750', '42.8');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('108', 'Jack Daniels Old No 7', '4590', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('109', 'Johnnie Walker Blue Label', '15000', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('110', 'El Dorado', '4500', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('111', 'Old Monk', '500', 'y', '750', '43');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('112', 'Clement', '5000', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('113', 'Absolut Vodka', '3000', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('114', 'Ciroc Red Berry', '9000', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('115', 'Cabernet Sauvignon', '900', 'y', '750', '13');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('116', 'Merlot Red Wine', '750', 'y', '750', '12');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('117', 'Patron', '42000', 'y', '750', '40');
INSERT INTO `lms`.`product` (`pid`, `pname`, `unitprice`, `instock`, `netqt`, `alc_per`) VALUES ('118', 'Don Angel', '3000', 'y', '750', '38');

UPDATE `lms`.`product` SET `bid` = '201' WHERE (`pid` = '101');
UPDATE `lms`.`product` SET `bid` = '202' WHERE (`pid` = '102');
UPDATE `lms`.`product` SET `bid` = '203' WHERE (`pid` = '103');
UPDATE `lms`.`product` SET `bid` = '204' WHERE (`pid` = '104');
UPDATE `lms`.`product` SET `bid` = '205' WHERE (`pid` = '105');
UPDATE `lms`.`product` SET `bid` = '206' WHERE (`pid` = '106');
UPDATE `lms`.`product` SET `bid` = '207' WHERE (`pid` = '107');
UPDATE `lms`.`product` SET `bid` = '208' WHERE (`pid` = '108');
UPDATE `lms`.`product` SET `bid` = '207' WHERE (`pid` = '109');
UPDATE `lms`.`product` SET `bid` = '209' WHERE (`pid` = '110');
UPDATE `lms`.`product` SET `bid` = '210' WHERE (`pid` = '111');
UPDATE `lms`.`product` SET `bid` = '211' WHERE (`pid` = '112');
UPDATE `lms`.`product` SET `bid` = '206' WHERE (`pid` = '113');
UPDATE `lms`.`product` SET `bid` = '207' WHERE (`pid` = '114');
UPDATE `lms`.`product` SET `bid` = '207' WHERE (`pid` = '115');
UPDATE `lms`.`product` SET `bid` = '207' WHERE (`pid` = '116');
UPDATE `lms`.`product` SET `bid` = '212' WHERE (`pid` = '117');
UPDATE `lms`.`product` SET `bid` = '212' WHERE (`pid` = '118');

UPDATE `lms`.`product` SET `catid` = '301' WHERE (`pid` = '101');
UPDATE `lms`.`product` SET `catid` = '301' WHERE (`pid` = '102');
UPDATE `lms`.`product` SET `catid` = '301' WHERE (`pid` = '103');
UPDATE `lms`.`product` SET `catid` = '301' WHERE (`pid` = '104');
UPDATE `lms`.`product` SET `catid` = '302' WHERE (`pid` = '105');
UPDATE `lms`.`product` SET `catid` = '303' WHERE (`pid` = '106');
UPDATE `lms`.`product` SET `catid` = '303' WHERE (`pid` = '107');
UPDATE `lms`.`product` SET `catid` = '304' WHERE (`pid` = '108');
UPDATE `lms`.`product` SET `catid` = '303' WHERE (`pid` = '109');
UPDATE `lms`.`product` SET `catid` = '305' WHERE (`pid` = '110');
UPDATE `lms`.`product` SET `catid` = '305' WHERE (`pid` = '111');
UPDATE `lms`.`product` SET `catid` = '305' WHERE (`pid` = '112');
UPDATE `lms`.`product` SET `catid` = '306' WHERE (`pid` = '113');
UPDATE `lms`.`product` SET `catid` = '306' WHERE (`pid` = '114');
UPDATE `lms`.`product` SET `catid` = '307' WHERE (`pid` = '115');
UPDATE `lms`.`product` SET `catid` = '307' WHERE (`pid` = '116');
UPDATE `lms`.`product` SET `catid` = '308' WHERE (`pid` = '117');
UPDATE `lms`.`product` SET `catid` = '308' WHERE (`pid` = '118');

INSERT INTO `lms`.`customer` (`cid`, `cname`, `pass`, `dob`, `phone`, `address`) VALUES ('1000', 'Rahul', 'rahul', '1999-09-09', '9876543210', 'Mysore');
INSERT INTO `lms`.`customer` (`cid`, `cname`, `pass`, `dob`, `phone`, `address`) VALUES ('1001', 'Sonu', 'sonu', '1992-02-11', '9876543211', 'Mandya');
INSERT INTO `lms`.`customer` (`cid`, `cname`, `pass`, `dob`, `phone`, `address`) VALUES ('1002', 'Sharath', 'sharat', '2000-02-05', '7349669469', 'Hunsur');
INSERT INTO `lms`.`customer` (`cid`, `cname`, `pass`, `dob`, `phone`, `address`) VALUES ('1003', 'Dhanush', 'dhanus', '2000-01-01', '9880302468', 'Mysore');
INSERT INTO `lms`.`customer` (`cid`, `cname`, `pass`, `dob`, `phone`, `address`) VALUES ('1004', 'Harshith', 'harshi', '2000-01-01', '6363958903', 'Mysore');
INSERT INTO `lms`.`customer` (`cid`, `cname`, `pass`, `dob`, `phone`, `address`) VALUES ('1005', 'Rohan', 'rohan', '2000-05-05', '9876543213', 'Mangalore');
INSERT INTO `lms`.`customer` (`cid`, `cname`, `pass`, `dob`, `phone`, `address`) VALUES ('1006', 'Lisha', 'lisha', '2002-07-21', '9876543214', 'Bangalore');

INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10000', 'Done', 'Card');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10001', 'Done', 'Cash');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10002', 'Pend', 'Online');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10003', 'Done', 'Cash');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10004', 'Pend', 'Online');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10005', 'Done', 'Card');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10006', 'Pend', 'Online');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10007', 'Done', 'Online');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10008', 'Done', 'Cash');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10009', 'Done', 'Card');
INSERT INTO `lms`.`payment` (`pyid`, `pystatus`, `method`) VALUES ('10010', 'Done', 'Card');

INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5000', '10000', '1000', '2020-12-07', 'Processed', '2020-12-07', '6000');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5001', '10001', '1001', '2019-05-05', 'Processed', '2019-05-05', '20000');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `total`) VALUES ('5002', '10002', '1002', '2020-10-05', 'Processing', '50000');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5003', '10003', '1003', '2020-05-11', 'Processed', '2020-05-12', '8500');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5004', '10004', '1004', '2020-08-15', 'Processed', '2020-08-15', '2500');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5005', '10005', '1005', '2020-11-22', 'Processed', '2020-11-22', '12500');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5006', '10006', '1006', '2020-12-07', 'Processed', '2020-12-07', '7000');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `total`) VALUES ('5007', '10007', '1003', '2020-12-21', 'Processing', '6050');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5008', '10008', '1002', '2020-02-02', 'Processed', '2020-02-05', '7500');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5009', '10009', '1004', '2020-02-05', 'Processed', '2020-02-05', '23000');
INSERT INTO `lms`.`orders` (`oid`, `pyid`, `cid`, `odate`, `ostatus`, `dl_date`, `total`) VALUES ('5010', '10010', '1000', '2020-02-02', 'Processed', '2020-02-02', '11500');

INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5000, 101, 2);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5000, 102, 2);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5000, 103, 2);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5001, 109, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5001, 110, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5001, 111, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5002, 117, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5002, 112, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5002, 105, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5003, 101, 3);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5003, 103, 5);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5004, 111, 5);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5005, 107, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5005, 106, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5006, 118, 2);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5006, 115, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5007, 118, 2);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5008, 116, 10);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5009, 109, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5009, 107, 1);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5010, 112, 2);
INSERT INTO `lms`.`includes` (`oid`, `pid`, `no_units`) VALUES (5010, 111, 3);

-- Stored Procedures Part

-- SP to return the total number of rows in temp_cart
USE `lms`;
DROP procedure IF EXISTS `count_temp_cart`;

USE `lms`;
DROP procedure IF EXISTS `lms`.`count_temp_cart`;
;

DELIMITER $$
USE `lms`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `count_temp_cart`(OUT no_rows integer)
begin
	select count(*) into no_rows 
    from lms.temp_cart;
end$$

DELIMITER ;
;

-- SP to fill includes table
USE `lms`;
DROP procedure IF EXISTS `fill_includes_table`;

USE `lms`;
DROP procedure IF EXISTS `lms`.`fill_includes_table`;
;

DELIMITER $$
USE `lms`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `fill_includes_table`()
BEGIN
	DECLARE total_cart INT;
    DECLARE x INT;
    DECLARE m_o INT;
    DECLARE pid_now INT;
    DECLARE no_units_now INT;
    DECLARE cur CURSOR FOR SELECT pid, no_units from lms.temp_cart;
    
    SET total_cart := (select count(lms.temp_cart.pid) from lms.temp_cart);
    
    call max_oid(@last_oid);
	SET m_o := (select @last_oid);
    
    SET x = 0;
    
    OPEN cur;
    
    fill_includes: LOOP
		IF x = total_cart THEN
			LEAVE fill_includes;
		END IF;
        
        SET x = x + 1; 
        
        FETCH cur INTO pid_now, no_units_now;
        
        INSERT INTO lms.includes values (pid_now, m_o, no_units_now);
        
        ITERATE fill_includes;
	END LOOP;
        
	CLOSE cur;
END$$

DELIMITER ;
;

-- SP to return most recent order ID
USE `lms`;
DROP procedure IF EXISTS `max_oid`;

USE `lms`;
DROP procedure IF EXISTS `lms`.`max_oid`;
;

DELIMITER $$
USE `lms`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `max_oid`(OUT last_oid integer)
begin
	select max(oid) into last_oid from orders; 
end$$

DELIMITER ;
;

-- SP to return most recent Payment ID
USE `lms`;
DROP procedure IF EXISTS `max_pyid`;

USE `lms`;
DROP procedure IF EXISTS `lms`.`max_pyid`;
;

DELIMITER $$
USE `lms`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `max_pyid`(OUT last_pyid integer)
begin
	select max(pyid) into last_pyid from payment; 
end$$

DELIMITER ;
;

-- SP to return the total cost of all the products in temp_cart
USE `lms`;
DROP procedure IF EXISTS `total_price`;

USE `lms`;
DROP procedure IF EXISTS `lms`.`total_price`;
;

DELIMITER $$
USE `lms`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `total_price`(OUT total_price_final integer)
begin
	select sum(p.unitprice * tc.no_units) into total_price_final
    from lms.temp_cart tc, lms.product p 
    where tc.pid = p.pid;
end$$

DELIMITER ;
;

-- Trigger Part

-- trigger to fill includes whenever a new order is placed
DROP TRIGGER IF EXISTS fill_includes;
DELIMITER $$
	CREATE TRIGGER fill_includes
    AFTER INSERT ON lms.orders
    FOR EACH ROW
    BEGIN
         call fill_includes_table;   
	END$$
DELIMITER ;

-- trigger to archive customers whenever a customer record is deleted from the table
DROP TRIGGER IF EXISTS archive_customer;
DELIMITER $$
	CREATE TRIGGER archive_customer
    AFTER DELETE ON lms.customer
    FOR EACH ROW
    BEGIN
         INSERT INTO  lms.customer_archive
         VALUES (OLD.cid, OLD.cname, OLD.pass, OLD.dob, OLD.phone, OLD.address);
	END$$
DELIMITER ;











